# Exercise: Areas

**Course:** Programming with Python (mooc.fi)  
**Part:** Part 10  
**Module:** Class hierarchies  
**Date:** YYYY-MM-DD  
**Difficulty:** [Easy / Tricky / Struggled]  
**Tags:** `#class` `#part10`

---

## Prompt

> One or two sentences describing what the exercise asked you to do.

---

## My Solution

```python
# your code here
```

## Model / Best Solution

```python
# model code here
```

---

## Key Differences

| | My Solution | Model Solution |
|---|---|---|
| [Aspect 1] | | |
| [Aspect 2] | | |

---

## What I Learned

- **[Concept]** — explanation
- **[Concept]** — explanation

---

## Questions / Still Unclear

- [ ] ...
- [ ] ...
