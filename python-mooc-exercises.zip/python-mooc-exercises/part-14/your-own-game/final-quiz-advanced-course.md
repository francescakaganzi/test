# Exercise: Final quiz, Advanced Course

**Course:** Programming with Python (mooc.fi)  
**Part:** Part 14  
**Module:** Your own game  
**Date:** YYYY-MM-DD  
**Difficulty:** [Easy / Tricky / Struggled]  
**Tags:** `#your` `#part14`

---

## Prompt

> One or two sentences describing what the exercise asked you to do.

---

## My Solution

```python
# your code here
```

## Model / Best Solution

```python
# model code here
```

---

## Key Differences

| | My Solution | Model Solution |
|---|---|---|
| [Aspect 1] | | |
| [Aspect 2] | | |

---

## What I Learned

- **[Concept]** — explanation
- **[Concept]** — explanation

---

## Questions / Still Unclear

- [ ] ...
- [ ] ...
