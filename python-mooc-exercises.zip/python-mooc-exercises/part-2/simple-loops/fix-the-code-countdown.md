# Exercise: Fix the code: Countdown

**Course:** Programming with Python (mooc.fi)  
**Part:** Part 2  
**Module:** Simple loops  
**Date:** YYYY-MM-DD  
**Difficulty:** [Easy / Tricky / Struggled]  
**Tags:** `#simple` `#part2`

---

## Prompt

> One or two sentences describing what the exercise asked you to do.

---

## My Solution

```python
# your code here
```

## Model / Best Solution

```python
# model code here
```

---

## Key Differences

| | My Solution | Model Solution |
|---|---|---|
| [Aspect 1] | | |
| [Aspect 2] | | |

---

## What I Learned

- **[Concept]** — explanation
- **[Concept]** — explanation

---

## Questions / Still Unclear

- [ ] ...
- [ ] ...
